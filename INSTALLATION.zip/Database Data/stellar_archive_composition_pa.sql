CREATE DATABASE  IF NOT EXISTS `stellar_archive` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `stellar_archive`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: stellar_archive
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `composition_pa`
--

DROP TABLE IF EXISTS `composition_pa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `composition_pa` (
  `PLANET` varchar(50) NOT NULL,
  `MASS_KG` varchar(50) DEFAULT NULL,
  `CarbonDioxide` varchar(50) DEFAULT NULL,
  `Nitrogen` varchar(50) DEFAULT NULL,
  `Oxygen` varchar(50) DEFAULT NULL,
  `Argon` varchar(50) DEFAULT NULL,
  `Methane` varchar(50) DEFAULT NULL,
  `Sodium` varchar(50) DEFAULT NULL,
  `Hydrogen` varchar(50) DEFAULT NULL,
  `Helium` varchar(50) DEFAULT NULL,
  `Others` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`PLANET`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `composition_pa`
--

LOCK TABLES `composition_pa` WRITE;
/*!40000 ALTER TABLE `composition_pa` DISABLE KEYS */;
INSERT INTO `composition_pa` VALUES ('Earth','1.4*10^21',NULL,'78%','21%','1%',NULL,NULL,NULL,NULL,'<1%'),('Jupiter','1.9*10^27',NULL,NULL,NULL,NULL,NULL,NULL,'89.8%','10.2%',NULL),('Mars','2.5*10^16','95%','2.7%',NULL,'1.6%',NULL,NULL,NULL,NULL,'0.7%'),('Mercury','1000',NULL,NULL,'42%',NULL,NULL,'22%','22%','6%','8%'),('Moon','100,000',NULL,NULL,NULL,'70%',NULL,'1%',NULL,'29%',NULL),('Neptune','1*10^26',NULL,NULL,NULL,NULL,'1%',NULL,'80%','19%',NULL),('Pluto','1.3*10^14','8%','90%',NULL,NULL,'2%',NULL,NULL,NULL,NULL),('Saturn','5.4*10^26',NULL,NULL,NULL,NULL,NULL,NULL,'96.3%','3.2%','0.5%'),('Sun','3*10^30',NULL,NULL,NULL,NULL,NULL,NULL,'71%','26%','3%'),('Titan','9.1*10^18',NULL,'97%',NULL,NULL,'2%',NULL,NULL,NULL,'1%'),('Uranus','8.6*10^25',NULL,NULL,NULL,NULL,'2.3%',NULL,'82.5%','15.2%',NULL),('Venus','4.8*10^20','96%','4%',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `composition_pa` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-26 18:13:21
