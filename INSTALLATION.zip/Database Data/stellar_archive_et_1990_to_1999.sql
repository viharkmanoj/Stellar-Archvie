CREATE DATABASE  IF NOT EXISTS `stellar_archive` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `stellar_archive`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: stellar_archive
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `et_1990_to_1999`
--

DROP TABLE IF EXISTS `et_1990_to_1999`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `et_1990_to_1999` (
  `DATE` char(4) DEFAULT NULL,
  `MISSION` varchar(130) NOT NULL,
  `COUNTRY` varchar(20) DEFAULT NULL,
  `MISSION_NAME` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`MISSION`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `et_1990_to_1999`
--

LOCK TABLES `et_1990_to_1999` WRITE;
/*!40000 ALTER TABLE `et_1990_to_1999` DISABLE KEYS */;
INSERT INTO `et_1990_to_1999` VALUES ('1991','First asteroid flyby','USA','Galileo'),('1992','First confirmed observation of an exoplanet','CANADA',' Dale Frail'),('1998','First multinational space station','FKA,NASA,ESA,JAXA,CS','ISS'),('1997','First operational rover on MARS','USA','Mars Pathfinder'),('1995','First orbit of Jupiter','USA','Galileo'),('1997','First orbital radio observatory','JAPAN','HALCA'),('1990','First photograph of the whole Solar System','USA','Voyager 1'),('1992','First polar orbit around the Sun','USA,ESA','Ulysses'),('1995','First space laser-communication','JAPAN','ETS-VI'),('1995','First spacecraft to enter the atmosphere of JUPITER','USA','Galileo'),('1992','First spacecraft to map Venus in its entirety','USA','Megellan'),('1997','First spacecraft to use aerobraking to enter orbit','USA','Mars Global Surveyor'),('1990','First telescope designed to be repaired in space','USA,ESA','Hubble Space Telescope'),('1990','First time a spacecraft coming from deep space','ESA','Giotto'),('1995','Record longest duration spaceflight','RUSSIA','Mir');
/*!40000 ALTER TABLE `et_1990_to_1999` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-26 18:13:16
