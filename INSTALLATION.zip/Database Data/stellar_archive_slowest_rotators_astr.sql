CREATE DATABASE  IF NOT EXISTS `stellar_archive` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `stellar_archive`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: stellar_archive
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `slowest_rotators_astr`
--

DROP TABLE IF EXISTS `slowest_rotators_astr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `slowest_rotators_astr` (
  `MINOR_PLANET_DESIG` varchar(80) NOT NULL,
  `ROTATION_PERIOD_IN_HRS` varchar(10) DEFAULT NULL,
  `MAGNITUDE` varchar(10) DEFAULT NULL,
  `QUALITY` varchar(10) DEFAULT NULL,
  `ORBIT_OR_FAMILY` varchar(40) DEFAULT NULL,
  `SPECTRAL_TYPE` varchar(10) DEFAULT NULL,
  `DIAMETER_IN_KM` varchar(10) DEFAULT NULL,
  `ABS_MAG_IN_H` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`MINOR_PLANET_DESIG`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slowest_rotators_astr`
--

LOCK TABLES `slowest_rotators_astr` WRITE;
/*!40000 ALTER TABLE `slowest_rotators_astr` DISABLE KEYS */;
INSERT INTO `slowest_rotators_astr` VALUES ('(162058) 1997 AE12','1880','0.6','2','NEO','S','0.782','17.9'),('(219774) 2001 YY145','1007.7','0.86','2','MBA(INNER)','S','1.54','16.43'),('(39546) 1992 DT5','1167.4','0.8','2','MBA(OUTER)','C','5.34','15.09'),('(75482) 1999 XC173','1234.2','0.69','2','VESTIAN','S','2.96','15.01'),('1235 SCHORRIA','1265','1.4','3','HUNGARIA','CX:','5.04','13.1'),('2440 EDUCATIO','1561','0.8','2','FLORA','S','6.51','13.1'),('2675 TOLKIEN','1060','0.75','2+','FLORA','S','9.85','12.2'),('288 GLAUKE','1170','0.9','3','MBA(OUTER)','S','32.24','10'),('4524 BARKLAJDETOLLI','1069','1.26','2','FLORA','S','7.14','12.9'),('496 GRYPHIA','1072','1.25','3','FLORA','S','15.47','11.61'),('50719 ELIZABETHGRIFFIN','1256','0.42','2','EUNOMIA','S','3.4','14.65'),('846 LIPPERTA','1641','0.3','2','THEMIS','CBU:','52.41','10.26'),('912 MARITIMA','1332','0.18','3-','MBA(OUTER)','C','82.14','9.3'),('9165 RAUP','1320','1.34','3-','HUNGARIA','S','4.62','13.6');
/*!40000 ALTER TABLE `slowest_rotators_astr` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-26 18:13:15
