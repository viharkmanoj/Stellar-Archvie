CREATE DATABASE  IF NOT EXISTS `stellar_archive` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `stellar_archive`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: stellar_archive
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `protoplanetary_nebula`
--

DROP TABLE IF EXISTS `protoplanetary_nebula`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `protoplanetary_nebula` (
  `NAME` varchar(20) NOT NULL,
  `NGC` varchar(50) DEFAULT NULL,
  `OTHER_DESIGNATION` varchar(50) DEFAULT NULL,
  `DATE_DISCOVERED` varchar(50) DEFAULT NULL,
  `DISTANCE` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `protoplanetary_nebula`
--

LOCK TABLES `protoplanetary_nebula` WRITE;
/*!40000 ALTER TABLE `protoplanetary_nebula` DISABLE KEYS */;
INSERT INTO `protoplanetary_nebula` VALUES ('BOOMERANG NEBULA','---','CENTAURUS BIPOLAR NEBULA','---','ABOUT 5000'),('CALABASH NEBULA','---','OH231.8+4.2','---','ABOUT 4200'),('COTTON CANDY NEBULA ','---','IRAS 17150-3224','---','---'),('EGG NEBULA','---','CRL 2688','1996','ABOUT 3000'),('FROSTY LEO NEBULA','---','IRAS 09371+1212','---','ABOUT 3000'),('LL Pegasi','---','IRAS 23166+1655','---','---'),('M1-92','---','IRAS 19343+2926','---','About 8000'),('Minkowski\'s Butterfl','---','M2-9','---','About 2100'),('NO NAME-1','---','IRAS 22036+5306','---','---'),('NO NAME-2','---','IRAS 13208-6020','---','---'),('NO NAME-3','---','IRAS 20068+4051','---','---'),('NO NAME-4','---','IRAS 19024+0044','---','About 11000'),('RED RECTANGULAR NEBU','---','HD 44179','1973','2300±300'),('Roberts 22(MR 22)','---','AFGL 4104','---','---'),('WATER LILY NEBULA','---','IRAS 16594-4656','---','---'),('WESTBROOK NEBULA','---','IRAS 04395+3601','---','--');
/*!40000 ALTER TABLE `protoplanetary_nebula` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-26 18:13:17
