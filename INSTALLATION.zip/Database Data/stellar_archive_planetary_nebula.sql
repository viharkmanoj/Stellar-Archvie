CREATE DATABASE  IF NOT EXISTS `stellar_archive` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `stellar_archive`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: stellar_archive
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `planetary_nebula`
--

DROP TABLE IF EXISTS `planetary_nebula`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `planetary_nebula` (
  `NAME` varchar(50) NOT NULL,
  `MESSIER_CATALOUGE` varchar(50) DEFAULT NULL,
  `NGC` varchar(50) DEFAULT NULL,
  `OTHER_DESIGNATION` varchar(50) DEFAULT NULL,
  `DATE_DISCOVERED` varchar(5) DEFAULT NULL,
  `DISTANCE` varchar(50) DEFAULT NULL,
  `APPARENT_MAGNITUDE` varchar(50) DEFAULT NULL,
  `CONSTELLATION` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `planetary_nebula`
--

LOCK TABLES `planetary_nebula` WRITE;
/*!40000 ALTER TABLE `planetary_nebula` DISABLE KEYS */;
INSERT INTO `planetary_nebula` VALUES ('ANT NEBULA','---','---','MZ 3','1922','8.0','13.8','NORMA'),('BLINKING PLANETARY','---','NGC 6826','Caldwell 15','---','2.0','8.8','CYGNUS'),('BLUE FLASH NEBULA','---','NGC 6905','---','1784','7.5','10.9','DELPHINUS'),('BLUE RACQUETBALL','---','NGC 6572','---','1825','2.5','8.1','OPHIUCHUS'),('BLUE SNOWBALL NEBULA','---','NGC 7662','---','1784','---','8.6','ANDROMEDA'),('BOW TIE NEBULA','---','NGC 40','CALDWELL 2','1788','3.5','11.4','CEPHEUS'),('BUG NEBULA','---','NGC 6302','CALDWELL 69','1888','3.4','7.1B','SCORPIUS'),('BUTTERFLY NEBULA','---','NGC 2346','---','1802','3.9','11.9','MONOCEROS'),('CATS EYE NEBULA','---','NGC6543','---','1786','3.3','9.8B','DRACO'),('CLEOPARTRAS EYE','---','NGC 1535','---','1785','6.5','10.5','ERIDANUS'),('DUMBBELL NEBULA','M27','NGC 6853','---','1764','1.36','7.5','VULPECULA'),('EIGHT-BURST NEBULA','---','NGC 3132','---','1888','2.6','9.87','VELA'),('ENGRAVED HOURGLASS NEBULA ','---','---','MYCN 18','1996','8.0','13.0','MUSCA'),('ESKIMO NEBULA','---','NGC 2392','---','1787','2.9','10.1','GEMINI'),('FETUS NEBULA','---','NGC 7008','---','1787','2.7','12','CYGNUS'),('FLEMING 1','---','---','G290+0.7.9/ESO 170-6','1888','7.9','13.1','CENTAURIUS'),('FOOTPRINT NEBULA','---','---','M1-92','1946','15.0','11.7','CYGNUS'),('GHOST OF JUPITER','---','NGC 3242','---','1785','1.4','8.6','HYDRA'),('GLOWING EYE NEBULA','---','NGC 6751','---','1863','6.5','11.9','AQUILA'),('HELIX NEBULA','---','NGC 7293','---','1824','0.68+0.15/-0.08','7.6','AQUARIUS'),('JEWEL BUG NEBULA','---','NGC 7027','---','1878','3.0','10','CYGNUS'),('JONESEMBERSON 1','---','---','PK 164+31.1','1939','1.6','14.0','LYNX'),('LEMON SLICE NEBULA','---','---','IC 3568','1918','4.5','12','CAMELOPARDALIS'),('LITTLE DUMBBELL','M76','NGC 650','---','1780','3.4','10.1','PERSEUS'),('LITTLE GHOST NEBULA','---','NGC 6369','---','1800','---','9.9','OPHIUCHUS'),('MEDUSA NEBULA','---','---','ABELL 21','1955','1.0','15.99','GERMINI'),('NO NAME-1','---','NGC 7026','---','1873','5.6','10.0','CYGNUS'),('NO NAME-10','---','NGC 2022','---','1785','7','12.8','ORION'),('NO NAME-11','---','NGC 2371','---','1785','4.3','13','GEMINI'),('NO NAME-12','---','NGC 6781','---','1788','2.5','11.4','AQUILLA'),('NO NAME-13','---','NGC 6790','---','1882','11','10.5','AQUILA'),('NO NAME-14','---','NGC 6881','---','1881','---','13.8','CYGNUS'),('NO NAME-15','---','NGC 6884','---','1883','6.5','10.9','CYGNUS'),('NO NAME-16','---','NGC 6891','---','1884','7.2','10.5','DELPHINUS'),('NO NAME-17','---','NGC 6886','---','1884','15.0+3.3','11.8','SAGITTA'),('NO NAME-18','---','NGC 6742','ABELL 50','1788','---','16.5','DRACO'),('NO NAME-19','---','NGC 6894','PK 069-02.1','1784','4.2','12.3','CYGNUS'),('NO NAME-2','---','---','ABELL 39','1955','6.8','13.7','HERCULES'),('NO NAME-20','---','NGC 6804','---','1791','12.5','11.2','AQUILA'),('NO NAME-21','---','NGC 7354','---','1787','5.5','---','CEPHEUS'),('NO NAME-22','---','NGC 6803','---','1882','12.5','11.1','AQUILA'),('NO NAME-23','---','---','ABELL 78','1966','---','13','CYGNUS'),('NO NAME-24','---','---','ABELL 31','1955','2','12.2','CANCER'),('NO NAME-25','---','---','IC 1454','1891','13.7','14','CEPHEUS'),('NO NAME-26','---','---','ABELL 12','---','6.9','---','ORION'),('NO NAME-27','---','---','HEN 2-47','---','6.6','---','CARINA'),('NO NAME-28','---','NGC 5844','---','1837','---','12.7','TRIANGULUM ASTRALE'),('NO NAME-29','---','NGC 5979','---','1835','13','12.10','TRIANGULUM ASTRALE'),('NO NAME-3','---','---','IC 289','1888','5.2','---','CASSIOPEIA'),('NO NAME-30','---','NGC 6565','---','---','---','14','SAGITTARRIUS'),('NO NAME-31','---','NGC 2438','---','1786','2.9','11.5','PUPPIS'),('NO NAME-32','---','NGC 2240','---','1790','3.6','9.3','PUPPIS'),('NO NAME-33','---','---','IC 1295','1867','4.7','12.7','SCUTUM'),('NO NAME-34','---','---','IC 2448','1898','11','11.10','CARINA'),('NO NAME-35','---','---','IC 4663','1901','11','---','SCORPIUS'),('NO NAME-36','---','---','MZ 1','1922','3.4','12','NORMA'),('NO NAME-37','---','NGC 3918','BLUE PLANETARY','1834','4.9','8.5','CENTAURUS'),('NO NAME-38','---','NGC 6578','---','1882','5.5','13.5','SAGITTARIUS'),('NO NAME-39','---','---','IC 4191','1907','---','11.6','MUSCA'),('NO NAME-4','---','---','IC 2194','1906','12','10.84','HERCULES'),('NO NAME-40','---','---','IC 4634','1893','7.5','11.3','OPHIUCHUS'),('NO NAME-41','---','---','IC 4637','1901','7.8','12.5','SCORPIUS'),('NO NAME-42','---','NGC 2452','---','1847','---','12.20','PUPPIS'),('NO NAME-43','---','NGC 2899','---','1835','6.5','11.8','VELA'),('NO NAME-44','---','NGC 2792','---','1835','---','11.6','VELA'),('NO NAME-45','---','NGC 2818','---','1826','10.4','12.50','PYXIS'),('NO NAME-46','---','NGC 2867','---','1834','7.3','10','CARINA'),('NO NAME-47','---','NGC 3211','---','1837','---','11.5','CARINA'),('NO NAME-48','---','NGC 3195','---','1835','5.5','11.6','CHAMAELEON'),('NO NAME-49','---','NGC 4361','---','1785','3','10.9','CORVUS'),('NO NAME-5','---','---','IC4593','1907','12','10.84','HERCULES'),('NO NAME-50','---','NGC 5307','---','1836','10','11.2','CENTAURUS'),('NO NAME-51','---','NGC 5315','---','1883','7','9.8','CIRCINUS'),('NO NAME-52','---','NGC 5882','---','1834','---','9.4','LUPUS'),('NO NAME-53','---','NGC 6072','---','1837','3.1','14','SCORPIUS'),('NO NAME-6','---','---','IC 4997','---','8','11','SAGITTA'),('NO NAME-7','---','NGC6058','---','1787','---','13','HERCULES'),('NO NAME-8','---','NGC 7048','PK 088-01.1','1878','5.2','12.1','CYGNUS'),('NO NAME-9','---','NGC 1514','---','1790','2.2','9.4','TAURUS'),('OWL NEBULA','M97','NGC 3587','---','1781','2.6','9.9','URSA MAJOR'),('OYSTER NEBULA ','---','NGC 1501','---','1787','4.2','13','CAMELOPARDALIS'),('RED SPIDER NEBULA','---','NGC 6537','---','1868','3.9','11.9','SAGITTARIUS'),('RETINA NEBULA','---','---','IC 4406','1888-','2.0','---','LUPUS'),('RING NEBULA','M57','NGC 6720','---','1779','2.3','9','LYRA'),('ROBIN\'S EGG NEBULA','---','NGC 1360','---','1868','1.5','9.4','FORMAX'),('SATURN NEBULA','---','NGC 7009','---','1782','3.0','8.0','AQUARIUS'),('SHAPLEY 1','---','---','PLN 329+2.1','1939','-1','12.6','NORMA'),('SKULL NEBULA','---','NGC246','---','1785','1.6','8','CETUS'),('SOAP BUBBLE NEBULA','---','---','PN G75.51.7','2008','4','---','CYGNUS'),('SOCCER BALL NEBULA','---','---','KRONBERGER 61','2011','13','18.4','CYGNUS'),('SOUTHERN CRAB NEBULA','---','---','HEN 2-104','1967','7','14.20','CENTAURUS'),('SOUTHERN OWL NEBULA','---','---','PN K 1-22 ESO 378-1','1971','4.3','17.4','HYDRA'),('SPARE-TYRE NEBULA','---','---','IC 1548','1894','3','16.5','GRUS'),('SPIRAL PLANETARY','---','NGC 5189','---','1835','2.6','9.5','MUSCA'),('SPIROGRAPH','---','---','IC 418','1888-','1.3','9.6','LEPUS'),('STRINGRAY NEBULA','---','---','HEN 3-1357','1989','18','10.75','ARA'),('TURTLE NEBULA','---','NGC 6210','---','1825','4.7','9.3','HERCULES'),('TWIN JET NEBULA','---','---','M2-9','1947','2.1','14.7','OPHIUCHUS');
/*!40000 ALTER TABLE `planetary_nebula` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-26 18:13:22
