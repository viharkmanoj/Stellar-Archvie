CREATE DATABASE  IF NOT EXISTS `stellar_archive` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `stellar_archive`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: stellar_archive
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fact_sheet`
--

DROP TABLE IF EXISTS `fact_sheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fact_sheet` (
  `PLANET` varchar(10) NOT NULL,
  `MASS` varchar(10) DEFAULT NULL,
  `DIAMETER` varchar(10) DEFAULT NULL,
  `DENSITY` varchar(10) DEFAULT NULL,
  `GRAVITY` varchar(10) DEFAULT NULL,
  `ESCAPE_VELOCITY` varchar(10) DEFAULT NULL,
  `ROTATION_PERIOD` varchar(10) DEFAULT NULL,
  `LENGTH_OF_DAY` varchar(10) DEFAULT NULL,
  `DISTANCE_FROM_SUN` varchar(10) DEFAULT NULL,
  `ORBITAL_PERIOD` varchar(10) DEFAULT NULL,
  `ORBITAL_VELOCITY` varchar(10) DEFAULT NULL,
  `ORBITAL_ECCENTRICITY` varchar(10) DEFAULT NULL,
  `OBLIQUITY_TO_ORBIT` varchar(10) DEFAULT NULL,
  `SURFACE_PRESSURE` varchar(10) DEFAULT NULL,
  `NO_OF_MOONS` varchar(10) DEFAULT NULL,
  `RING_SYSTEM` varchar(10) DEFAULT NULL,
  `MAGNETIC_FIELD` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`PLANET`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fact_sheet`
--

LOCK TABLES `fact_sheet` WRITE;
/*!40000 ALTER TABLE `fact_sheet` DISABLE KEYS */;
INSERT INTO `fact_sheet` VALUES ('EARTH','1','1','1','1','1','1','1','1','1','1','1','1','1','1','NO','YES'),('JUPITER','317.8','11.21','0.241','2.36','5.32','0.415','0.414','5.20','11.9','0.439','2.93','0.134','--','92','YES','YES'),('MARS','0.107','0.532','0.714','0.377','0.450','1.03','1.03','1.52','1.88','0.808','5.60','1.07','0.01','2','NO','NO'),('MERCURY','0.0553','0.383','0.985','0.378','0.384','58.8','175.9','0.387','0.241','1.59','12.3','0.001','0','0','NO','YES'),('NEPTUNE','17.1','3.88','0.297','1.12','2.10','0.673','0.671','30.18','163.7','0.182','0.677','1.21','--','14','YES','YES'),('PLUTO','0.0022','0.187','0.336','0.071','0.116','6.41','6.39','39.48','247.9','0.157','14.6','2.45','0.00001','5','NO','--'),('SATURN','95.2','9.45','0.125','0.916','3.17','0.445','0.444','9.57','29.4','0.325','3.38','1.14','--','83','YES','YES'),('URANUS','14.5','4.01','0.230','0.889','1.90','-0.720','0.718','19.17','83.7','0.228','2.74','4.17','--','27','YES','YES'),('VENUS','0.815','0.949','0.951','0.907','0.926','-244','116.8','0.723','0.615','1.18','0.401','0.113','92','0','NO','NO');
/*!40000 ALTER TABLE `fact_sheet` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-26 18:13:21
