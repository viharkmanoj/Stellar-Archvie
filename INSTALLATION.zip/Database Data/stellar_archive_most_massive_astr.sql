CREATE DATABASE  IF NOT EXISTS `stellar_archive` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `stellar_archive`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: stellar_archive
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `most_massive_astr`
--

DROP TABLE IF EXISTS `most_massive_astr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `most_massive_astr` (
  `NAME` varchar(50) NOT NULL,
  `MASS` varchar(20) DEFAULT NULL,
  `PRECISION_VALUE` varchar(20) DEFAULT NULL,
  `APPROX_PROPORTION_OF_ALL_ASTR` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `most_massive_astr`
--

LOCK TABLES `most_massive_astr` WRITE;
/*!40000 ALTER TABLE `most_massive_astr` DISABLE KEYS */;
INSERT INTO `most_massive_astr` VALUES ('1 CERES','938.35 ','0.001%','39.2%'),('10 HYGIEA','87','8%','3.6%'),('107 CAMILLA',' 11.2','1%','0.5%'),('15 EUNOMIA','30','6%','1.3%'),('16 PSYCHE','23','13%','1%'),('2 PALLAS','204','1.5%','8.5%'),('29 AMPHITRITE','13','16%','0.5%'),('3 JUNO','27','9%','1.1%'),('31 EUPHROSYNE','17','18%','0.7%'),('324 BAMBERGA','10','9%','0.4% '),('4 VESTA','259.076','0.0004%','10.8%'),('511 DAVIDA','27','27%','1.1%'),('52 EUROPA','24','16%','1%'),('532 HRCULINA','≈23','?','≈1%'),('6 HEBE','12','20%','0.5%'),('65 CYBELE','15','12%','0.6%'),('7 IRIS','14','17%','0.6%'),('704 INTERAMNIA','35','14%','1.5%'),('87 SYLVIA','14.76','0.4%','0.6%'),('88 THISBE','12','20%','0.5%');
/*!40000 ALTER TABLE `most_massive_astr` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-26 18:13:22
