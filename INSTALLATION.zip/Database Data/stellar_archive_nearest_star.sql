CREATE DATABASE  IF NOT EXISTS `stellar_archive` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `stellar_archive`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: stellar_archive
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `nearest_star`
--

DROP TABLE IF EXISTS `nearest_star`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nearest_star` (
  `STAR_SYSTEM` varchar(50) NOT NULL,
  `DISTANCE_IN_LIGHT_YEAR` varchar(50) DEFAULT NULL,
  `STELLAR_TYPE` varchar(50) DEFAULT NULL,
  `OBSERVED_PLANETS` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`STAR_SYSTEM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nearest_star`
--

LOCK TABLES `nearest_star` WRITE;
/*!40000 ALTER TABLE `nearest_star` DISABLE KEYS */;
INSERT INTO `nearest_star` VALUES ('61 CYGNI','11.40','K;K','--'),('AD LEONIS','15.94','M','--'),('ALPHA CENTAURI','4.24-4.37','M;G;K','1'),('BARDNARDS STAR','5.96','M ','--'),('DEN 0255-4700','16.20','L','--'),('DEN 1048-3956','13.17','M','--'),('DENIS J081730.0-615520','16.07','T','--'),('DX CANCRI','11.83','M','--'),('EPSILON ERIDANI','10.52','K','2'),('EPSILON INDI','11.82','K;T;T','--'),('EZ AQUARII','11.27','M;M;M','--'),('GJ 1002','1531','M','--'),('GJ 1061','11.99','M','--'),('GJ 1245','14.81','M;M;M','--'),('GLIESE 1','14.23','M','--'),('GLIESE 412','15.83','M;M','--'),('GLIESE 440','15.06','D','--'),('GLIESE 674','14.81','M','1'),('GLIESE 687','14.80','M','--'),('GLIESE 832','16.08','M','1'),('GLIESE 876','15.34','M','4'),('GROOMBRIDGE 1618','15.85','K','--'),('GROOMBRIDGE 34','11.62','M;M','--'),('KAPTEYN STAR','12.78','M','--'),('KRUGER 60','13.15','M;M','--'),('LACAILLE 8760','12.87','M','--'),('LACAILLE 9352','10.74','M','--'),('LALANDE 21185','8.29','M','--'),('LHS 288','15.61','M','--'),('LHS 292','14.80','M','--'),('LP 944-020','16.19','M','--'),('LUYTEN 726-8','8.73','M;M','--'),('LUYTEN STAR','12.37','M','--'),('PROCYON','11.40','F;D','--'),('ROSS 128','10.92','M','--'),('ROSS 154','9.68','M','--'),('ROSS 248','10.32','M','--'),('ROSS 614','13.35','M;M','--'),('SCR 1845-6357','12.57','M;T','--'),('SIRIUS','8.58','A;D','--'),('STRUVE 2398','11.53','M;M','--'),('TAU CETI','11.89','G','5'),('TEEGARDEN STAR','12.51','M','--'),('TZ ARIETIS','14.51','M','--'),('UGPS 0722-05','13.26','T','--'),('VAN MAANEN STAR','14.07','D','--'),('WISE 0350-5658','13.70','Y','--'),('WISE 1405+5534','15.76','Y','--'),('WISE 1541-2250','13.70','Y','--'),('WOLF 1061','13.82','M','--'),('WOLF 359','7.78','M','--'),('WOLF 424','14.31','M;M','--'),('YZ CETI','12.13','M','--');
/*!40000 ALTER TABLE `nearest_star` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-26 18:13:19
