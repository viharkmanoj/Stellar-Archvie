CREATE DATABASE  IF NOT EXISTS `stellar_archive` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `stellar_archive`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: stellar_archive
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `et_1980_to_1989`
--

DROP TABLE IF EXISTS `et_1980_to_1989`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `et_1980_to_1989` (
  `DATE` char(4) DEFAULT NULL,
  `MISSION` varchar(130) NOT NULL,
  `COUNTRY` varchar(20) DEFAULT NULL,
  `MISSION_NAME` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`MISSION`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `et_1980_to_1989`
--

LOCK TABLES `et_1980_to_1989` WRITE;
/*!40000 ALTER TABLE `et_1980_to_1989` DISABLE KEYS */;
INSERT INTO `et_1980_to_1989` VALUES ('1989','First astrometric satellite','ESA','Hipparcos'),('1985','First balloon deployed on another planet (Venus)','USSR','Vega 1'),('1986','First close up observations of a comet (Halley\'s Comet)','ESA','Giotto'),('1986','First consistently inhabited long-term research space station','USSR','MIR'),('1983','First Infrared orbital observatory','USA,UK','IRAS'),('1982','First mixed gender crew aboard space station','USSR','Salyut 7'),('1989','First orbital cosmic microwave observatory','USA','COBE'),('1982','First plants grown in space (Arabidopsis)','USSR','Salyut 7'),('1981','First reusable crewed orbital spacecraft (Space Shuttle)','USA','STS-1'),('1983','First spacecraft beyond the orbit of Neptune','USA','Pioneer 10'),('1982','First spacecraft to conduct a deep survey of Earth\'s magnetic tail','USA','ISEE-3/ICE'),('1985','First spacecraft to flyby a comet (21P/Giacobini-Zinner)','USA','ISEE-3/ICE'),('1989','First spacecraft to flyby Neptune','USA','Voyager 2'),('1986','First spacecraft to flyby Uranus','USA','Voyager 2'),('1984','First spacewalk by a woman (Svetlana Savitskaya)','USSR','Salyut 7'),('1988','First suspected detection of an exoplanet Gamma Cephei Ab','CANADA','Bruce Campbell'),('1984','First untethered spacewalk (Bruce McCandless II)','USA','STS-41-B'),('1982','First Venus soil samples','USSR','Venera 13'),('1980','Saturn flyby close encounter of Titan','USA','Voyager 1');
/*!40000 ALTER TABLE `et_1980_to_1989` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-26 18:13:21
