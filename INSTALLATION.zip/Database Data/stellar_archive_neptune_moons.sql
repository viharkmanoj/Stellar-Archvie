CREATE DATABASE  IF NOT EXISTS `stellar_archive` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `stellar_archive`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: stellar_archive
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `neptune_moons`
--

DROP TABLE IF EXISTS `neptune_moons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `neptune_moons` (
  `NAME` varchar(50) NOT NULL,
  `ABS_MAGN` varchar(50) DEFAULT NULL,
  `DIAMETER` varchar(50) DEFAULT NULL,
  `MASS` varchar(50) DEFAULT NULL,
  `SEMIMAJOR_AXIS` varchar(50) DEFAULT NULL,
  `ORBITAL_PERIOD` varchar(50) DEFAULT NULL,
  `ORBITAL_INCLINATION` varchar(50) DEFAULT NULL,
  `ECCENTRICITY` varchar(50) DEFAULT NULL,
  `DISCOVERY_YEAR` varchar(50) DEFAULT NULL,
  `DISCOVERER` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `neptune_moons`
--

LOCK TABLES `neptune_moons` WRITE;
/*!40000 ALTER TABLE `neptune_moons` DISABLE KEYS */;
INSERT INTO `neptune_moons` VALUES ('DESPINA','7.3','156','≈170','52 526','+0.3346','0.068','0.0004','1989','Voyager Science Team'),('GALATEA','7.2','174.8','≈280','61 953','+0.4287','0.034','0.0001','1989','Voyager Science Team'),('HALIMEDE','10.0','≈62','≈12','16 590 100','-1 879.30','113.1','0.286','2002','Holman et al'),('HIPPOCAMP','10.5','34.8±4.0','≈2.2','105 283','+0.9500','0.064','0.0005','2013','Showalter et al'),('LAOMEDEIA','10.8','≈42','≈3.4','23 502 300','+3 175.65','37.7','0.409','2002','Holman et al'),('LARISSA','6.8','194','≈380','73 548','+0.5555','0.205','0.0012','1981','Reitsema et al'),('NAIAD','9.6','60.4','≈13','48 224','+0.2944','4.691','0.0047','1989','Voyager Science Team'),('NEREID','4.4','357 ± 13','≈2400','5 504 000','+360.14','5.8','0.749','1949','Kuiper'),('NESO','10.7','≈60','≈11','49 871 600','-9 796.67','126.9','0.400','2002','Holman et al'),('PROTEUS','5.0','420','≈3900','117 646','+1.1223','0.075','0.0005','1989','Voyager Science Team'),('PSAMATHE','11.0','≈40','≈2.9','47 611 900','-9 149.87','126.6','0.417','2003','Sheppard et al'),('SAO','11.1','≈44','≈3.4','22 239 300','+2918.70','53.3','0.148','2002','Holman et al'),('THALASSA','8.7','81.4','≈35','50 074','+0.3115','0.135','0.0018','1989','Voyager Science Team'),('TRITON','-1.2','2705.2±4.8','2 139 000','354 759','-5.8769','156.865','0.0000','1846','Lassell');
/*!40000 ALTER TABLE `neptune_moons` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-26 18:13:20
