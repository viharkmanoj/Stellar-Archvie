CREATE DATABASE  IF NOT EXISTS `stellar_archive` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `stellar_archive`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: stellar_archive
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `yearly_extragalatic_sn`
--

DROP TABLE IF EXISTS `yearly_extragalatic_sn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `yearly_extragalatic_sn` (
  `YEAR` varchar(10) NOT NULL,
  `TOTAL` varchar(10) DEFAULT NULL,
  `TYPE_1` varchar(10) DEFAULT NULL,
  `TYPE_2` varchar(10) DEFAULT NULL,
  `LBV` varchar(10) DEFAULT NULL,
  `BRIGHTER_THAN_APMAG_13` varchar(10) DEFAULT NULL,
  `APMAG_OF_BRIGHTEST_SN_OF_THAT_YEAR` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`YEAR`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yearly_extragalatic_sn`
--

LOCK TABLES `yearly_extragalatic_sn` WRITE;
/*!40000 ALTER TABLE `yearly_extragalatic_sn` DISABLE KEYS */;
INSERT INTO `yearly_extragalatic_sn` VALUES ('2000','196','76','49','1','0','13.1(2000cx in NGC 528)'),('2001','308','108','75','0','2','12.3(2001e1 in NGC 1448)'),('2002','352','163','64','0','1','12.3(2002ap in MESSIER 74)'),('2003','375','198','89','1','1','12.3(2003hv in NGC 1201)'),('2004','343','221','79','0','2','11.2(2004dj in NGC 2403)'),('2005','384','273','94','1','2','12.3(2005df in NGC 1559)'),('2006','557','418','124','2','3','12.1(2006dd in NGC 1316)'),('2007','605','442','130','1','3','12.0(2007it in NGC 5530)'),('2008','507','251','142','1','3','12.4(2008ge in NGC 1527)'),('2009','599','203','133','1','0','13.0(2009ig in NGC 1015)'),('2010','590','280','132','6','2','12.8(2010ih in NGC 2325)'),('2011','909','437','161','10','7','9.9(2011fe in MESSIER 101)'),('2012','1061','549','150','9','4','11.9(2012fr in NGC 1365)'),('2013','1552','494','189','7','6','11.3(2013aa in NGC 5643)'),('2014','2018','435','174','2','2','10.1(2014J in MESSIER 82)'),('2015','3519','699','210','4','2','12.9(2015F in NGC 2442)'),('2016','7305','672','224','3','0','13.0(2016coj in NGC 4125)'),('2017','7809','739','214','4','3','11.5(2017cbv in NGC 5643)'),('2018','7959','1188','324','6','3','12.7(2018pv in NGC 3941)'),('2019','16 154','1621','471','9','1','13.0(2019np in NGC 354)'),('2020','17 300','1624','440','7','5','11.8(2020ue in NGC 4636)'),('2021','21 072','1824','458','5','9','12.0(2021aefx in NGC 1566)'),('2022','19 336','1717','381','5','3','12.3(2022hrs in NGC 4647)');
/*!40000 ALTER TABLE `yearly_extragalatic_sn` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-26 18:13:17
