CREATE DATABASE  IF NOT EXISTS `stellar_archive` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `stellar_archive`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: stellar_archive
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `moonwalkers`
--

DROP TABLE IF EXISTS `moonwalkers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `moonwalkers` (
  `NAME` varchar(55) NOT NULL,
  `MISSION` varchar(50) DEFAULT NULL,
  `DOB` varchar(50) DEFAULT NULL,
  `DOD` varchar(50) DEFAULT NULL,
  `LUNAR_EVA_DATE` varchar(50) DEFAULT NULL,
  `EVAS_PERFORMED` varchar(50) DEFAULT NULL,
  `EVA_DURATION` varchar(50) DEFAULT NULL,
  `SERVICE` varchar(55) DEFAULT NULL,
  PRIMARY KEY (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moonwalkers`
--

LOCK TABLES `moonwalkers` WRITE;
/*!40000 ALTER TABLE `moonwalkers` DISABLE KEYS */;
INSERT INTO `moonwalkers` VALUES ('ALAN BEAN','APOLLO 12','Mar 15, 1932','May 26, 2018','Nov 19-20, 1969','2','7hrs 45mins','Navy'),('ALAN SHEPARD','APOLLO 14','Nov 18, 1923','July 21,1998','Feb 5-6, 1971 ','2','9hrs 21mins','Navy'),('BUZZ ALDRIN','APOLLO 11','Jan20,1930','ALIVE','July21,1969','1','2hrs 31mins','AirForce'),('CHARLES DUKE','APOLLO 16','Oct 3,1935','ALIVE','Apr 21-23, 1972','3','20hrs 14mins','Airforce'),('DAVID SCOTT','APOLLO 15','Jun 6, 1932','ALIVE','Jul 31-Aug 2, 1971','3','18hrs 33mins','AirForce'),('EDGAR MITCHELL','APOLLO 14','Sep 17,1930','Feb 4, 2016','Feb 5-6, 1971','2','9hrs 21mins','Navy'),('GENE CERNAN','APOLLO 17','Mar 14, 1934','Jan 16, 2017','Dec 11-14, 1972','3','22hrs 2mins','Navy'),('HARRISON SCHMITT','APOLLO 17','Jul 3, 1935','ALIVE','Dec 11-14, 1972','3','22hrs 2mins','NASA'),('JAMES IRWIN','APOLLO 15','Mar 17, 1930','Sep 8, 1991','Jul 31-Aug 2, 1971','3','18hrs 33mins','AirForce'),('JOHN YOUNG','APOLLO 16','Sep 24, 1930','Jan 5, 2018','Apr 21-23, 1972','3','20hrs 14mins','Navy'),('NEIL ARMSTRONG','APOLLO 11','Aug15,1930','Aug21,2012','July21,1969','1','2hrs 31mins','NASA'),('PETE CONARD','APOLLO 12','Jun 2,1930','Jul 8, 1999','Nov 19-20, 1969','2','7hrs 45mins','Navy');
/*!40000 ALTER TABLE `moonwalkers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-26 18:13:19
