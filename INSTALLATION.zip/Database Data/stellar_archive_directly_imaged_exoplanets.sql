CREATE DATABASE  IF NOT EXISTS `stellar_archive` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `stellar_archive`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: stellar_archive
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `directly_imaged_exoplanets`
--

DROP TABLE IF EXISTS `directly_imaged_exoplanets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `directly_imaged_exoplanets` (
  `STAR` varchar(50) NOT NULL,
  `EXOPLANET` varchar(50) DEFAULT NULL,
  `JUPITER_MASS` varchar(50) DEFAULT NULL,
  `JUPITER_RADIUS` varchar(50) DEFAULT NULL,
  `PERIOD` varchar(50) DEFAULT NULL,
  `OBSERVATION_SEP` varchar(50) DEFAULT NULL,
  `ECCENTRICITY` varchar(50) DEFAULT NULL,
  `DISTANCE_TO_EARTH` varchar(50) DEFAULT NULL,
  `YEAR_OF_DISCOVERY` varchar(50) DEFAULT NULL,
  `IMAGING_TECHNIQUE` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`STAR`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directly_imaged_exoplanets`
--

LOCK TABLES `directly_imaged_exoplanets` WRITE;
/*!40000 ALTER TABLE `directly_imaged_exoplanets` DISABLE KEYS */;
INSERT INTO `directly_imaged_exoplanets` VALUES ('1RXS J1609','1RXS 1609 B','8-14','1.7','6518','331.1','0.08','470','2008','DIRECT IMAGING'),('29 CYGNI','HIP 99770 B','13.9-16.1','1.05','51.0','16.9','0.25','130.9','2022','ALOCI'),('2M JO441444','2M JO44144','5-10','---','---','15','---','456','2010','DIRECT IMAGING'),('2M1207','2M1207B','4.2','1.5','1620','40.6','0.37','170','2004','DIRECT IMAGING'),('51 ERIDANI','51 ERIDANI b','2.6','1.0','?','13','?','96','2014','ADI KLIP'),('59 VIRGINS','GLIESE 504 B','---','?','?','43.5','?','57.27','2013','ADI,LOCI'),('AB AURIGAE','AB AURIGAE B','9-12','2.75','?','93','0.19-0.60','508','2022','ADI/RSDI,ALOI'),('AF Leporis','AF Lep b','2-5.5','---','20.6','8','0.47','87','2023','DIRECT IMAGING'),('ALPHA CENTAURI','---','0.11±0.05','0.459±0.17','1','1.1','---','4.37','2021','---'),('BD+60 1417','BD+60 1417 B','15±5','1.31±0.06','---','1662','---','144±13','2021','DIRECT IMAGING'),('BETA PICTORIS','Beta Pictoris b','2.7±0.3','1.5±0.2','22.47+3.77/-2.26','9','0.08+0.09/-0.05','63.4±0.1','2008','RSDI'),('DT VIRGINIS','ROSS 458(AB)','8.5','1.8','33.081','1167.7','0.17','38','2011','DIRECT IMAGING'),('FORMAHAUT','FORMALHAUT B','<2.0','---','872-2000','116.0','---','25','2008/2012','RSDI'),('FW TAURI','FW TAURI B','10±4','?','~12,000','330','?','472.93','2013','DIRECT IMAGING'),('GU PISCIUM','GU PISCIUM B','11±2','---','163,000','2000','---','155','2014','DIRECT IMAGING'),('HD 106906','HD 106906 B','11±2','?','?','650','?','300','2013','ADI'),('HD 169142','HD 169142 B','1-4','---','---','37.2','---','115','2019/2023','PSEUDO-ASDI,ADI'),('HD 203030','HD 203030 B','11+4/-3','---','---','487','---','128','2006','SDI'),('HD 95086','HD 95086 B','5.0','?','?','56','?','295','2013','ADI,LOCI'),('HIP 65426','HIP 65426B','6-12','1.5','600','92','','363','2017','ADI,TLOCI'),('HR 8799','HR 8799 E','7.0','1.3','49','14.5','0.14','128','2010','ADI KLIP'),('KAPPA','KAPPA B','---','?','242-900','55','0.69-0.85','168.0','2013','ADI,LOCI'),('L 34-26','COCONUTS-2B','6.3+1.5/-1.9','1.1±0.03','~1,100,000','6471','---','35.51±0.01','2021/2011','DIRECT IMAGING'),('PDS 70','PDS 70B','?','?','---','21','---','370','2018','ADI,TLOCI'),('ROXs 42B','ROXs 42B','9±3','2.5','1968.3','157','UNKNOWN','440±16','2013','DIRECT IMAGING'),('TYC 9486-927-1','2MASS J2126-8140','13.3±1.7','?','~900,000','6684','?','80.72±13.86','2016/2006','DIRECT IMAGING'),('VHS 1256-1257','VHS 1256 B','11.2','---','3900','102','---','40','2015','DIRECT IMAGING'),('WD 0806-661','WD 0806-661 B','7-9','?','?','2500','?','62','2011','DIRECT IMAGING');
/*!40000 ALTER TABLE `directly_imaged_exoplanets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-26 18:13:20
