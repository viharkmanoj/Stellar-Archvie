CREATE DATABASE  IF NOT EXISTS `stellar_archive` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `stellar_archive`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: stellar_archive
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `et_2010_and_later`
--

DROP TABLE IF EXISTS `et_2010_and_later`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `et_2010_and_later` (
  `DATE` char(4) DEFAULT NULL,
  `MISSION` varchar(130) NOT NULL,
  `COUNTRY` varchar(20) DEFAULT NULL,
  `MISSION_NAME` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`MISSION`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `et_2010_and_later`
--

LOCK TABLES `et_2010_and_later` WRITE;
/*!40000 ALTER TABLE `et_2010_and_later` DISABLE KEYS */;
INSERT INTO `et_2010_and_later` VALUES ('2021','First aerodynamically-powered flight on MARS','USA','Ingenuity'),('2022','First asteroid measurably deflected by a spacecraft','USA','DART'),('2021','First confirmed quake on MARS','USA','InSight'),('2019','First direct photograph of a black hole and its vicinity','USA','EHT'),('2015','First flyby and orbit of a dwarf planet (Ceres)','USA','Dawn'),('2019','First flyby of a classical Kuiper belt object (486958 Arrokoth)','USA','New Horizons'),('2015','First flyby of an object beyond Neptune (Pluto and its moons)','USA','New Horizons'),('2015','First food grown in space eaten (lettuce)','USA,JAPAN','ISS'),('2016','First inflatable space habitat','USA','BEAM'),('2017','First known interstellar object detected passing through the Solar System','USA','Oumuamua'),('2023','First landing at the lunar south pole on MOON','INDIA','Chandrayaan-3'),('2013','First laser communication with a lunar satellite','USA','LRO'),('2015','First observation of gravitational waves','LSC EGO','LIGO Virgo'),('2018','First operational rover on an asteroid (162173 Ryugu)','JAPAN','Hayabusa2'),('2011','First orbit of an object in the asteroid belt (4 Vesta)','USA','Dawn'),('2011','First orbit of Mercury','USA','MESSENGER'),('2021','First production of oxygen on MARS','USA','MOXIE'),('2015','First propulsive landing of a rocket','USA','New Shepard 2'),('2015','First propulsive landing of an orbital rocket','USA','Falcon 9'),('2018','First recorded sounds from Mars','USA','InSight'),('2010','First sample return fron asteroid(25143 Itokawa)','JAPAN','Hayabusa'),('2014','First soft landing on a comet (67P/Churyumov Gerasimenko)','ESA','Philae'),('2019','First soft landing on the far side of the Moon','CHINA','Chang\'e 4'),('2010','First solar sail','JAPAN','IKAROS'),('2017','First spacecraft to enter the atmosphere of Saturn','USA,ESA,ITALY','Cassini Huygens'),('2021','First spacecraft to fly through the atmosphere of a star (the Sun\'s corona)','USA','Parker Solar Probe'),('2012','First spacecraft to leave the heliosphere','USA','Voyager 1'),('2014','First spacecraft to orbit a comet nucleus(67P/Churyumov Gerasimenko)','ESA','Rosetta'),('2010','First spacecraft to orbit Moon\'s Lagrange point (L2)','USA','ARTEMIS-P1'),('2010','First spacecraft to orbit the Moon\'s Lagrange 1 point','USA','ARTEMIS-P2'),('2012','First use of a sky crane to land on MOON','USA','MSL'),('2021','Launch of the largest space telescope to date','USA,ESA,CANADA','JSWT');
/*!40000 ALTER TABLE `et_2010_and_later` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-26 18:13:20
