CREATE DATABASE  IF NOT EXISTS `stellar_archive` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `stellar_archive`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: stellar_archive
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `uranus_moons`
--

DROP TABLE IF EXISTS `uranus_moons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `uranus_moons` (
  `NAME` varchar(50) NOT NULL,
  `ABS_MAGN` varchar(50) DEFAULT NULL,
  `DIAMETER` varchar(50) DEFAULT NULL,
  `MASS` varchar(50) DEFAULT NULL,
  `SEMIMAJOR_AXIS` varchar(50) DEFAULT NULL,
  `ORBITAL_PERIOD` varchar(50) DEFAULT NULL,
  `ORBITAL_INCLINATION` varchar(50) DEFAULT NULL,
  `ECCENTRICITY` varchar(50) DEFAULT NULL,
  `DISCOVERY_YEAR` varchar(50) DEFAULT NULL,
  `DISCOVERER` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uranus_moons`
--

LOCK TABLES `uranus_moons` WRITE;
/*!40000 ALTER TABLE `uranus_moons` DISABLE KEYS */;
INSERT INTO `uranus_moons` VALUES ('ARIEL','1.0','1157.8±1.2','125 100 ± 2100','191 020','+2.52038','0.260°','0.0012','1851','Lassell'),('BELINDA','8.8','90 ± 16','≈49','75 260','+0.623 53','0.031°','0.00007','1986','Voyager 2'),('BIANCA','9.8','51 ± 4','≈9.2','59 170','+0.434 58','0.193°','0.000 92','1986','Voyager 2'),('CALIBAN','9.1','42','≈25','7 231 100','-579.73','141.529°','0.1812','1997','Gladman et al'),('CORDELIA','10.3','40 ± 6','≈4.4','49 770','+0.335 03','0.084 79°','0.000 26','1986','Voyager 2'),('CRESSIDA','8.9','80 ± 4','≈34','61 780','+0.463 57','0.006°','0.000 36','1986','Voyager 2'),('CUPID','12.6','≈18','≈0.38','74 800','+0.618 00','0.100°','0.0013','2003','Showalter and Lissauer'),('DESDEMONA','9.3','64 ± 8','≈18','62 680','+0.473 65','0.111 25°','0.000 13','1986','Voyager 2'),('FERDINAND','12.5','≈12','≈0.54','20 430 000','-2 790.03','169.793°','0.3993','2003','Holman et al'),('FRANCISCO','12.4','≈22','≈0.72','4 282 900','-267.09','147.250°','0.1324','2003','Holman et al'),('JULIET','8.5','94 ± 8','≈56','64 350','+0.493 07','0.065°','0.000 66','1986','Voyager 2'),('MAB','12.1','≈18','≈0.38','97 700','+0.923 00','0.1335°','0.0025','2003','Showalter and Lissauer'),('MARGARET','12.7','≈20','≈0.54','14 146 700','+1 661.00','57.367°','0.6772','2003','Sheppard and witt'),('MIRANDA','3.5','471.6 ± 1.4','6400±300','129 390','+1.41348','4.232°','0.0013','1948','Kuiper'),('OBERON','1.0','1 522.8±5.2','307 600±8700','583 520','+13.4632','0.058°','0.0014','1787','Herschel'),('OPHELIA','10.2','43 ± 8','≈5.3','53 790','+0.376 40','0.1036°','0.009 92','1986','Voyager 2'),('PERDITA','11.0','30 ± 6','≈1.8','76 400','+0.638 00','0.0°','0.0012','1999','Voyager 2'),('PORTIA','7.7','135 ± 8','≈170','66 090','+0.513 20','0.059°','0.000 05','1986','Voyager 2'),('PROSPERO','10.5','≈50','≈8.5','16 276 800','-1978.37','151.830°','0.4445','1999','Holman et al'),('PUCK','7.3','162 ± 4','≈290','86 010','+0.761 83','0.3192°','0.000 12','1985','Voyager 2'),('ROSALIND','9.1','72 ± 12','≈25','69 940','+0.558 46','0.279°','0.000 11','1986','Voyager 2'),('SETEBOS','10.7','≈48','≈7.5','17 420 400','-2 225.08','158.235°','0.5908','1999','Kavelaars et al'),('STEPHANO','9.7','≈32','≈2.2','8 007 400','-677.47','143.819°','0.2248','1999','Gladman et al'),('SYCORAX','7.4','157','≈230','12 179 400','-1288.38','159.420°','0.5219','1997','Nicholson et al'),('TITANIA','0.8','1 576.8±1.2','340 000±6100','435 910','+8.705 87','0.340°','0.0011','1787','Herschel'),('TRINCULO','12.7','≈18','≈0.39','8 505 200','-749.40','166.971°','0.2194','2001','Holman et al.'),('UMBRIEL','1.7','1169.4±5.6','127 500±2800','266 300','+4.144 18','0.205°','0.0039','1851','Lassell');
/*!40000 ALTER TABLE `uranus_moons` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-26 18:13:19
