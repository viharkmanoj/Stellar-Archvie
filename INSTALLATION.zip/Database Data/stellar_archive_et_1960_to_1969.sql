CREATE DATABASE  IF NOT EXISTS `stellar_archive` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `stellar_archive`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: stellar_archive
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `et_1960_to_1969`
--

DROP TABLE IF EXISTS `et_1960_to_1969`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `et_1960_to_1969` (
  `DATE` char(4) DEFAULT NULL,
  `MISSION` varchar(130) NOT NULL,
  `COUNTRY` varchar(20) DEFAULT NULL,
  `MISSION_NAME` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`MISSION`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `et_1960_to_1969`
--

LOCK TABLES `et_1960_to_1969` WRITE;
/*!40000 ALTER TABLE `et_1960_to_1969` DISABLE KEYS */;
INSERT INTO `et_1960_to_1969` VALUES ('1968','First animals to travel to and around the Moon','USSR','Zond 5'),('1966','First artificial satellite around MOON','USSR','Luna 10'),('1962','First auroral research rocket launched into the ionosphere','NORWAY','Ferdinand 1'),('1967','First automated (crewless) docking','USSR','Cosmos 186/Cosmos 188'),('1962','First communication between two crewed space vehicles in orbit','USSR','Vostok 3,4'),('1969','First crew exchange in space','USSR','Soyuz 4,5'),('1961','First crewed space flight lasting over twenty four hours by Gherman Titov','USSR','Vostok 2'),('1965','First crewed spacecraft to change orbit','USA','Gemini 3'),('1969','First docking of two crewed spacecraft around another celestial body','USA','Apollo 10'),('1965','First flyby of Mars (returned pictures)','USA','Mariner 4'),('1961','First hominidae in space(Ham)','USA','M-R 2'),('1968','First human excursion beyond low Earth orbit','USA','Apollo 8'),('1968','First human flight to MOON and its gravity influence','USA','Apollo 8'),('1969','First human on The MOON','USA','Apollo 11'),('1961','First human spaceflight (Yuri Gagarin)','USSR','Vostok 1'),('1961','First human-piloted space flight (Alan Shepard)','USA','Freedom 7'),('1966','First impact into another planet (Venus)','USSR','Venera 3'),('1961','First launch from Earth orbit of upper stage into a heliocentric orbit','USSR','Venera 1'),('1967','First liftoff from MOON','USA','Surveyor 6'),('1962','First Mars flyby (11,000 km) but contact was lost','USSR','Mars 1'),('1969','First meet up between human explorers and a robotic spacecraft in space','USA','Apollo 12/Surveyor 3'),('1964','First multi-person crew (3) in orbit','USSR','Voskhod 1'),('1966','First orbital docking between two spacecraft','USA','Gemini 8'),('1965','First orbital rendezvous (parallel flight, no docking)','USA','Gemini 6A/Gemini 7'),('1962','First orbital solar observatory','USA','OSO-1'),('1968','First orbital ultraviolet observatory','USA','OAO-2'),('1965','First photographs of another planet from deep space (Mars)','USA','	Mariner 4'),('1967','First photos of the Lunar south pole','USA','Lunar Orbiter 4'),('1966','First picture of Earth from MOON','USA','Lunar Orbiter 1'),('1962','First planetary flyby with data returned (Venus)','USA','Mariner 2'),('1961','First planetary flyby(venus)','USSR','Venera 1'),('1960','First plants and animals to return alive from Earth orbit','USSR','Sputnik 5'),('1967','First polar orbit around the Moon','USA','Lunar Orbiter 4'),('1960','First probe launched to Mars','USSR','Mars 1M'),('1963','First reusable crewed spacecraft (suborbital)','USA','X-15 Flight 90'),('1960','First rocket engine fired in spac','USA','Pioneer P-30'),('1969','First sample return from another celestial body','USA','Apollo 11'),('1966','First soft landing on MOON','USSR','Luna 9'),('1966','First soft-landing on the Moon','USA','Surveyor 1'),('1960','First solar probe','USA','Pioneer 5'),('1965','First space walk/extra-vehicular activity (Alexei Leonov)','USSR','Voskhod 2'),('1962','First spacecraft to impact the far side of the Moon','USA','Ranger 4'),('1969','First spacecraft to parachute in Venus\'s atmosphere','USSR','Venera 5'),('1963','First woman in space (Valentina Tereshkova)','USSR','Vostok 6');
/*!40000 ALTER TABLE `et_1960_to_1969` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-26 18:13:22
