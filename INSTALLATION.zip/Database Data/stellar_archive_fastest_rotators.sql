CREATE DATABASE  IF NOT EXISTS `stellar_archive` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `stellar_archive`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: stellar_archive
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fastest_rotators`
--

DROP TABLE IF EXISTS `fastest_rotators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fastest_rotators` (
  `MINOR_PLANET` varchar(50) NOT NULL,
  `ROTATION_PERIOD_IN_SEC` varchar(50) DEFAULT NULL,
  `MAG` varchar(10) DEFAULT NULL,
  `QUALITY` varchar(10) DEFAULT NULL,
  `ORBIT` varchar(10) DEFAULT NULL,
  `SPECTRAL_TYPE` varchar(10) DEFAULT NULL,
  `DIAMETER` varchar(10) DEFAULT NULL,
  `ABS_MAG` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`MINOR_PLANET`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fastest_rotators`
--

LOCK TABLES `fastest_rotators` WRITE;
/*!40000 ALTER TABLE `fastest_rotators` DISABLE KEYS */;
INSERT INTO `fastest_rotators` VALUES ('2000 DO8','78','1,39','3','NEO','S','0.037','24.54'),('2000 UK11','96','0.28','2','NEO','S','0.026','25.30'),('2000 WH10','80','0.66','3-','NEO','S','0.094','22.50'),('2007 KE4','77','0.38','3-','NEO','S','0.027','25.20'),('2008 HJ','43','0.80','3-','NEO','S','0.021','25.80'),('2008 TC3','97','1.02','3','NEO','F','0.004','30.90'),('2008 WA14','70','---','N.A','NEO','S','0.075','23'),('2009 BF2','57','0.80','3','NEO','S','0.02','25.90'),('2009 UD','84','0.66','2+','NEO','S','0.011','27.20'),('2010 JL88','25','0.52','3','NEO','S','0.013','26.80'),('2010 SK13','52','---','N.A','NEO','S','0.01','27.40'),('2010 TD54','83','0.92','3','NEO','S','0.005','28.90'),('2010 TG19','70','1.10','3','NEO','S','0.049','23.90'),('2010 TS19','83','---','N.A','NEO','S','0.022','25.70'),('2010 WA','31','0.22','3','NEO','S','0.003','30.00'),('2010 XE11','96','0.50','3','NEO','S','0.075','23'),('2012 HG2','82','---','N.A','NEO','S','0.012','27'),('2014 GQ17','78','0.08','2-','NEO','S','0.011','27.10'),('2014 RC','16','0.10','N.A','NEO','S','0.012','26.80'),('2014 TV','79','0.32','2','NEO','S','0.039','24.40'),('2014 WB366','86','0.46','2+','NEO','S','0.033','24.80'),('2015 AK45','93','0.24','2','NEO','S','0.016','26.40'),('2015 CM','96','0.53','3-','NEO','S','0.018','26.10'),('2015 RF36','90','0.15','2','NEO','S','0.062','23.40'),('2015 SU','46','0.20','2-','NEO','S','0.025','25.40'),('2015 SV6','18','0.74','2','NEO','S','0.009','27.70'),('2016 GE1','34','0.13','2','NEO','S','0.014','26.60'),('2016 GS2','66','0.06','1','NEO','S','0.075','23'),('2016 RB1','96','0.18','2+','NEO','S','0.007','28.30'),('2017 EK','30','0.30','2','NEO','S','0.045','24.10'),('2017 UK8','31','1.30','3','NEO','S','0.007','28.20'),('2099 TM8','43','---','N.A','NEO','S','0.006','28.40');
/*!40000 ALTER TABLE `fastest_rotators` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-26 18:13:19
