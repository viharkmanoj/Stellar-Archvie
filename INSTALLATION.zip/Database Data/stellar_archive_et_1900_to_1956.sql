CREATE DATABASE  IF NOT EXISTS `stellar_archive` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `stellar_archive`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: stellar_archive
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `et_1900_to_1956`
--

DROP TABLE IF EXISTS `et_1900_to_1956`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `et_1900_to_1956` (
  `DATE` char(4) DEFAULT NULL,
  `MISSION` varchar(130) NOT NULL,
  `COUNTRY` varchar(20) DEFAULT NULL,
  `MISSION_NAME` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`MISSION`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `et_1900_to_1956`
--

LOCK TABLES `et_1900_to_1956` WRITE;
/*!40000 ALTER TABLE `et_1900_to_1956` DISABLE KEYS */;
INSERT INTO `et_1900_to_1956` VALUES ('1933','British Interplanetary Society founded','UK','Philip E. Cleator'),('1919','Discussion of a Method of Reaching Extreme Altitudes','UNITED STATES','Robert H. Goddard'),('1927','Discussion on rocket mechanics and orbital effects','USSR','Yuri Kondratyuk'),('1928','Discussion space travel and its potential uses','USSR','Herman Potočnik'),('1933','Establishment of the Soviet rocket research lab','USSR','Valentin Glushko'),('1903','Exploration of the Universe with Rocket-Propelled Vehicles publication','RUSSIA','Konstantin Tsiolkovsky'),('1947','First animals in space (fruit flies)','UNITED STATES','V-2'),('1933','First detection of radio waves from an astronomical object','UNITED STATES','Karl Jansky'),('1945','First discussion of geostationary satellites as a means of communication','UK','Arthur C. Clarke'),('1949','First mammal in space (Albert II, a rhesus monkey)','UNITED STATES','V-2'),('1917','First observation of an extrasolar planet','NETHERLANDS','Adriaan van Maanen'),('1946','First pictures of Earth from 105 km','UNITED STATES','V-2'),('1956','First rocket to pass the thermopause and enter the exosphere','UNITED STATES','Jupiter-C'),('1946','First space research flight (cosmic radiation experiments)','UNITED STATES','Improved V-2 rocket'),('1944','First spaceflight in history','GERMANY','V-2 rocket (MW 18014)'),('1949','First two-stage liquid-fueled rocket','UNITED STATES','Bumper-5'),('1914','Goddard is awarded of patents on multistage and liquid-fueled rockets','UNITED STATES','Robert H. Goddard'),('1926','Goddard launches the first liquid-fueled rocket','UNITED STATES','Robert H. Goddard'),('1928','Lippisch Ente, first successful rocket-powered full-size aircraft','GERMANY','Max Valier'),('1929','Opel RAK.1, first successful public flight of a rocket-powered aircraft','GERMANY','Max Valier'),('1923','Publication of Die Rakete zu den Planetenräumen','GERMANY','Hermann Oberth'),('1924','Society for Studies of Interplanetary Travel founded','USSR','Yuri Kondratyuk'),('1927','Verein für Raumschiffahrt formed','GERMANY','By all top european scientists');
/*!40000 ALTER TABLE `et_1900_to_1956` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-26 18:13:18
