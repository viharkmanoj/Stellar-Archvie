CREATE DATABASE  IF NOT EXISTS `stellar_archive` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `stellar_archive`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: stellar_archive
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `et_1970_to_1979`
--

DROP TABLE IF EXISTS `et_1970_to_1979`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `et_1970_to_1979` (
  `DATE` char(4) DEFAULT NULL,
  `MISSION` varchar(130) NOT NULL,
  `COUNTRY` varchar(20) DEFAULT NULL,
  `MISSION_NAME` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`MISSION`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `et_1970_to_1979`
--

LOCK TABLES `et_1970_to_1979` WRITE;
/*!40000 ALTER TABLE `et_1970_to_1979` DISABLE KEYS */;
INSERT INTO `et_1970_to_1979` VALUES ('1970','First automatic sample return from the Moon','USSR','Luna 16'),('1971','First crewed orbital observatory','USSR','Orion 1'),('1978','First extended (multi-year) orbital exploration of Venus','USA','Pioneer Venus Orbiter'),('1973','First flyby of Jupiter','USA','Pioneer 10'),('1974','First flyby of Mercury','USA','Mariner 10'),('1979','First flyby of Saturn','USA','Pioneer 11'),('1970','First lunar rover','USSR','Lunokhod 1'),('1973','First mission sent to study Mercury','USA','Mariner 10'),('1971','First motor vehicle on another celestial body','USA','Apollo 15'),('1975','First multinational crewed mission','USSR,USA','Apollo-Soyuz Test Project'),('1972','First orbital gamma ray observatory','USA','SAS 2'),('1978','First real time remotely operated ultraviolet orbital observatory','USA,ESA,UK','Int Ultraviolet Explorer'),('1971','First signals from Martian surface','USSR','Mars 3'),('1970','First soft landing on another planet (Venus)','USSR','Venera 7'),('1971','First space station','USSR','Salyut 1'),('1972','First spacecraft to enter the asteroid belt','USA','Pioneer 10'),('1974','First spacecraft to flyby the same planet multiple times (Mercury)','USA','Mariner 10'),('1971','First spacecraft to impact another planet (Mars)','USSR','Mars 2'),('1971','First spacecraft to orbit another planet (Mars)','USA','Mariner 9'),('1978','First spacecraft to orbit the Sun at Lagrange 1','USA','ISEE-3/ICE'),('1975','First spacecraft to orbit Venus','USSR','Venera 9'),('1974','First spacecraft to return data on a long-period comet','USA','Mariner 10'),('1972','First spacecraft to use all-nuclear electrical power (SNAP-19 RTGs)','USA','Pioneer 10'),('1976','First successful photos and soil samples from the surface of Mars','USA','Viking Lander'),('1975','First successful photos from the surface of another planet (Venus)','USSR','Venera 9'),('1974','First use of solar wind for spacecraft orientation','USA','Mariner 10'),('1970','First X-ray orbital observatory','USA','Uhuru'),('1979','Jupiter flyby','USA','Voyager 1');
/*!40000 ALTER TABLE `et_1970_to_1979` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-26 18:13:16
